import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import { Container, Row, Col, Card } from "react-bootstrap";
import Home from "./pages/Home";
import Productos from "./pages/Productos";
import Ventas from "./pages/Ventas"; 
import Inventario from "./pages/Inventario";
import AppNavbar from "./components/Navbar";
import Footer from "./components/Footer";
import Hero from "./components/Hero";
import Login from "./pages/Login";
import { useNavigate } from "react-router-dom";



const ProtectedRoute = ({ children }) => {
  const token = localStorage.getItem("google_token");
  const navigate = useNavigate();

  if (!token) {
    return (
      <>
        <AppNavbar />
        <Hero />
        <Container className="my-5">
          <Row className="justify-content-center">
            <Col md={6}>
              <Card className="text-center shadow-lg p-4">
                <Card.Body>
                  <h2 className="fw-bold text-danger">Acceso Restringido</h2>
                  <p className="lead">Para acceder a esta sección, inicia sesión con Google.</p>
                  <div className="d-flex justify-content-center">
                    <GoogleLogin
                      onSuccess={(response) => {
                        console.log("Token de Google:", response.credential);
                        localStorage.setItem("google_token", response.credential);
                        navigate("/Productos"); 
                      }}
                      onError={() => console.error("Error en la autenticación")}
                    />
                  </div>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
        <Footer />
      </>
    );
  }

  return children;
};

function App() {
  return (
    <GoogleOAuthProvider clientId="429908816051-80j1hf60q4t94tu5ikq0rbgtpleeanc4.apps.googleusercontent.com">
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/productos" element={<ProtectedRoute><Productos /></ProtectedRoute>} />
        <Route path="/ventas" element={<ProtectedRoute><Ventas /></ProtectedRoute>} />
        <Route path="/inventario" element={<ProtectedRoute><Inventario /></ProtectedRoute>} />
        <Route path="/login" element={<ProtectedRoute><Login /></ProtectedRoute>} />
        <Route path="*" element={<h1>404: Página no encontrada</h1>} />

      </Routes>
    </Router>
    </GoogleOAuthProvider>
  );
}

export default App;
