import React from "react";

const Footer = () => {
  return (
    <footer className="text-white text-center py-3" >
      <p>
        &copy; 2025 Sistema de inventario. Desarrollado por Carol Jácome & Steven Oviedo. Todos los derechos
        reservados.
      </p>
    </footer>
  );
};

export default Footer;
