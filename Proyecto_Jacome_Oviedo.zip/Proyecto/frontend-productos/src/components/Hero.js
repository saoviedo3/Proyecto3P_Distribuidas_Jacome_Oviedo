import React from "react";
import { Container } from "react-bootstrap";

const Hero = () => {
  return (
    <div
      style={{
        backgroundImage: "url('https://via.placeholder.com/1920x500')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        color: "white",
        padding: "100px 0",
        textAlign: "center",
      }}
    >
      <Container>
      <br />
        <h1 className="display-4 fw-bold">¡Bienvenido al Sistema de Inventario!</h1>
        <br />
        <br />
        <p className="lead">
          Por favor inicie sesión con Google para acceder a las funcionalidades del sistema.
        </p>
        
      </Container>
    </div>
  );
};

export default Hero;
