import React from "react";
import { Navbar, Nav, Container, Button} from "react-bootstrap";
import { NavLink } from "react-router-dom"; 
import { FaHome, FaBox, FaClipboardList, FaShoppingCart, FaSignInAlt } from "react-icons/fa"; 
import { useNavigate } from "react-router-dom";
import logo from "../assets/logo.png"; 
const userName = localStorage.getItem("google_user_name");

const AppNavbar = () => {
  const token = localStorage.getItem("google_token");

  const navigate = useNavigate(); 
  const handleLogout = () => {
    localStorage.removeItem("google_token");

    navigate("/"); 
  };


  return (
    <Navbar
      style={{ backgroundColor: "#4a90e2", boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.2)" }}
      variant="light"
      expand="lg"
    >
      <Container>
        <Navbar.Brand as={NavLink} to="/" className="d-flex align-items-center">
          <img
            src={logo}
            alt="Gestión de Inventario"
            style={{
              height: "50px",
              marginRight: "15px",
              filter: "drop-shadow(2px 2px 5px rgba(0,0,0,0.3))",
            }}
          />
          <span style={{ color: "#fff", fontSize: "1.5rem" }}>
            El buen sabor!
          </span>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            {/* Enlaces con íconos y rutas actualizadas */}
            <Nav.Link
              as={NavLink}
              to="/"
              exact="true"
              className="text-light mx-2 d-flex align-items-center"
              style={{ fontSize: "1.1rem" }}
            >
              <FaHome style={{ marginRight: "8px" }} />
              Inicio
            </Nav.Link>
            {token && (
            <Nav.Link
              as={NavLink}
              to="/Productos"
              className="text-light mx-2 d-flex align-items-center"
              style={{ fontSize: "1.1rem" }}
            >
              <FaBox style={{ marginRight: "8px" }} />
              Productos
            </Nav.Link>
            )}
            {token && (
            <Nav.Link
              as={NavLink}
              to="/Inventario"
              className="text-light mx-2 d-flex align-items-center"
              style={{ fontSize: "1.1rem" }}
            >
              <FaClipboardList style={{ marginRight: "8px" }} />
              Inventario
            </Nav.Link>
            )}
            {token && (
            <Nav.Link
              as={NavLink}
              to="/ventas"
              className="text-light mx-2 d-flex align-items-center"
              style={{ fontSize: "1.1rem" }}
            >
              <FaShoppingCart style={{ marginRight: "8px" }} />
              Ventas
            </Nav.Link>
            )}

            {token && <span className="text-light mx-2">{userName}</span>}


            {token && (
              <Button
                variant="outline-light"
                onClick={handleLogout}
                style={{ marginLeft: "10px" }}
              >
                Cerrar Sesión
              </Button>
            )}

            {!token && (
            <Nav.Link
              as={NavLink}
              to="/Login"
              className="text-light mx-2 d-flex align-items-center"
              style={{ fontSize: "1.1rem" }}
            >
              <FaSignInAlt style={{ marginRight: "8px" }} />
              Iniciar Sesión
            </Nav.Link>

            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default AppNavbar;

