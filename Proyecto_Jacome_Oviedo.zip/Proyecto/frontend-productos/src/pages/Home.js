import React from "react";
import { Row, Col, Card } from "react-bootstrap";
import AppNavbar from "../components/Navbar";
import Footer from "../components/Footer";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBoxes, faClipboardList, faChartBar } from "@fortawesome/free-solid-svg-icons";
import "../styles.css";

const Home = () => {
  return (
    <>
      <AppNavbar />
      <br />
      <br />
      <div className="hero-section d-flex flex-column align-items-center justify-content-center text-center text-white">
        <h1 className="display-3 text-white mb-3">¡Bienvenido a tu Inventario!</h1>
        <p className="lead text-white mb-4">Gestiona tus productos y stock de manera eficiente y en tiempo real.</p>
      </div>
      <br />
      <br />
        <Row className="g-4 d-flex justify-content-center">
          <Col md={10} lg={8}>
            <Card className="h-100 border-0 shadow flex-row align-items-center">
              <div className="p-4">
                <FontAwesomeIcon icon={faBoxes} size="4x" className="text-info" />
              </div>
              <Card.Body>
                <Card.Title>Gestión de Productos</Card.Title>
                <Card.Text>
                  Agrega, edita y elimina productos de tu inventario con facilidad.
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>
          <Col md={10} lg={8}>
            <Card className="h-100 border-0 shadow flex-row align-items-center">
              <div className="p-4">
                <FontAwesomeIcon icon={faClipboardList} size="4x" className="text-success" />
              </div>
              <Card.Body>
                <Card.Title>Control de Stock</Card.Title>
                <Card.Text>
                  Mantén actualizado el nivel de stock de tus productos en tiempo real.
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>
          <Col md={10} lg={8}>
            <Card className="h-100 border-0 shadow flex-row align-items-center">
              <div className="p-4">
                <FontAwesomeIcon icon={faChartBar} size="4x" className="text-warning" />
              </div>
              <Card.Body>
                <Card.Title>Reportes y Estadísticas</Card.Title>
                <Card.Text>
                  Genera informes detallados sobre el estado de tu inventario.
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      <Footer />
    </>
  );
};

export default Home;
