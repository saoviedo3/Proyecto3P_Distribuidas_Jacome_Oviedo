import React, { useEffect, useState } from "react";
import { Container, Table, Button, Form, Alert } from "react-bootstrap";
import axios from "axios";
import { FaFilePdf, FaArrowLeft } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import Chart from "chart.js/auto";
import AppNavbar from "../components/Navbar";
import Footer from "../components/Footer";

const Inventario = () => {
  const [productos, setProductos] = useState([]);
  const [filtroStock, setFiltroStock] = useState("todos");
  const navigate = useNavigate();
  const API_URL = "http://20.185.83.63:8005/api/productos";

  useEffect(() => {
    obtenerProductos();
  }, []);

  const obtenerProductos = async () => {
    try {
      const response = await axios.get(API_URL);
      setProductos(response.data);
    } catch (error) {
      console.error("Error al obtener productos:", error);
    }
  };

  const productosFiltrados = productos.filter((producto) => {
    if (filtroStock === "bajo") return producto.stock < 5;
    if (filtroStock === "alto") return producto.stock >= 5;
    return true;
  });

  const generarPDF = () => {
    const doc = new jsPDF();

    doc.setFont("helvetica", "bold");
    doc.setFontSize(26);
    doc.setTextColor(0, 102, 51); 
    doc.text("Frutería El Buen Sabor!", 105, 20, { align: "center" });

    doc.setFontSize(16);
    doc.setTextColor(33, 33, 33);
    doc.text("Reporte de Inventario", 105, 30, { align: "center" });

    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("Fecha:", 15, 50);
    doc.setFont("helvetica", "normal");
    const fechaActual = new Date();
    const fechaFormateada = fechaActual.toLocaleDateString("es-ES", { day: "2-digit", month: "long", year: "numeric" });
    doc.text(fechaFormateada, 35, 50);

    doc.setFontSize(16);
    doc.setTextColor(33, 33, 33); 
    doc.text("Productos en Stock", 105, 60, { align: "center" });

    const tablaColumnas = ["Nombre", "Stock", "Unidad", "Categoría"];
    
    // Crear filas de la tabla y definir estilos condicionales
    const tablaFilas = productosFiltrados.map((prod) => [
        prod.nombre,
        prod.stock,
        prod.unidadMedida,
        prod.categoria
    ]);

    // Generar la tabla con estilos condicionales
    autoTable(doc, {
        head: [tablaColumnas],
        body: tablaFilas,
        startY: 75, 
        theme: "grid",
        headStyles: {
            fillColor: [0, 102, 51], 
            textColor: 255,
            fontStyle: "bold",
            halign: "center",
        },
        styles: { halign: "center", fontSize: 11, cellPadding: 3 },
        columnStyles: {
            0: { halign: "left" },  
            1: { halign: "center" }, 
            2: { halign: "center" },
            3: { halign: "left" }
        },
        didParseCell: function (data) {
            if (data.section === "body" && data.column.index === 1) { // Columna de stock
                const stockValue = parseInt(data.cell.raw);
                if (stockValue < 5) {
                    data.cell.styles.fillColor = [255, 87, 51]; // 🔴 Rojo para stock bajo
                    data.cell.styles.textColor = 255;
                }
            }
        }
    });

    const finalY = doc.lastAutoTable.finalY + 10; 

    // Crear un canvas para el gráfico
    const canvas = document.createElement("canvas");
    canvas.width = 400;
    canvas.height = 200;
    const ctx = canvas.getContext("2d");

    // Definir colores para cada producto según stock
    const barColors = productosFiltrados.map((p) => (p.stock < 5 ? "#FF5733" : "#4CAF50"));

    new Chart(ctx, {
        type: "bar",
        data: {
            labels: productosFiltrados.map((p) => p.nombre),
            datasets: [
                {
                    label: "Stock",
                    data: productosFiltrados.map((p) => p.stock),
                    backgroundColor: barColors, // Aplica colores dinámicamente
                },
            ],
        },
        options: {
            responsive: false,
            plugins: {
                legend: { display: false },
            },
            scales: {
                y: { beginAtZero: true },
            },
        },
    });

    // Esperar a que el gráfico se renderice y agregarlo al PDF
    setTimeout(() => {
        const imgData = canvas.toDataURL("image/png");
        doc.addImage(imgData, "PNG", 35, finalY, 140, 80);
        doc.save("Inventario.pdf");
    }, 500);
};


  

  return (
    <>
      <AppNavbar />
      <Container className="mt-5">
        <div className="d-flex justify-content-between align-items-center mb-4">
        <Button style={{ backgroundColor: "#4CAF50", borderColor: "#4CAF50", color: "white" }} onClick={() => navigate("/")}>
        <FaArrowLeft /> Atrás
          </Button>
          <h2 className="text-center flex-grow-1">Inventario</h2>
        </div>

        <Form.Group className="mb-3">
          <h3 className="flex-grow-1">Filtrar por Stock</h3>
          <Form.Select value={filtroStock} onChange={(e) => setFiltroStock(e.target.value)}>
            <option value="todos">Todos</option>
            <option value="bajo">Stock Bajo (Menos de 5)</option>
            <option value="alto">Stock Suficiente</option>
          </Form.Select>
        </Form.Group>

        <Table striped bordered hover responsive>
          <thead>
            <tr className="text-center">
              <th>Nombre</th>
              <th>Stock</th>
              <th>Categoría</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            {productosFiltrados.map((producto) => (
              <tr key={producto.id} className={producto.stock < 5 ? "table-danger" : "table-success"}>

                <td>{producto.nombre}</td>
                <td className="text-center">{producto.stock}</td>
                <td>{producto.categoria}</td>
                <td className="text-center">
                  {producto.stock < 5 ? <Alert variant="danger">Stock Bajo</Alert> : <Alert variant="success">Suficiente</Alert>}
                </td>
              </tr>
            ))}
          </tbody>
        </Table>

        <Button variant="danger" onClick={generarPDF} className="mt-3">
          <FaFilePdf /> Generar Informe PDF
        </Button>
        <br />
      </Container>

      <br />

      <Footer />
    </>
  );
};

export default Inventario;