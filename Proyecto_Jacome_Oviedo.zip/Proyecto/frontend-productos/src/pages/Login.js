import React from "react";
import { GoogleLogin } from "@react-oauth/google";
import { Container, Row, Col, Card } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import AppNavbar from "../components/Navbar";
import Footer from "../components/Footer";
import Hero from "../components/Hero";
import "../styles.css";


const Login = () => {

const navigate = useNavigate();

  return (
    <>
      <AppNavbar />
      <Hero />
      <Container className="my-5">
        <Row className="justify-content-center">
          <Col md={6}>
            <Card className="text-center shadow-lg p-4">
              <Card.Body>
                <h2 className="fw-bold text-danger">Acceso Restringido</h2>
                <p className="lead">Para acceder a esta sección, inicia sesión con Google.</p>
                <div className="d-flex justify-content-center">
                  <GoogleLogin
                    onSuccess={(response) => {
                      console.log("Token de Google:", response.credential);
                      localStorage.setItem("google_token", response.credential);
                      navigate("/Productos"); 
                    }}
                    onError={() => console.error("Error en la autenticación")}
                  />
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
      <Footer />
    </>
  );
};


export default Login;
