import React, { useEffect, useState } from "react";
import { Table, Button, Container, Modal, Form, Alert } from "react-bootstrap";
import axios from "axios";
import { FaEdit, FaTrash, FaPlus, FaArrowLeft } from "react-icons/fa"; // Iconos de Bootstrap
import { useNavigate } from "react-router-dom"; // Para redireccionar
import AppNavbar from "../components/Navbar"; // Importamos el Navbar
import Footer from "../components/Footer"; // Importamos el Navbar

const Productos = () => {
  const [productos, setProductos] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  const [productoActual, setProductoActual] = useState({
    id: null,
    nombre: "",
    descripcion: "",
    precio: "",
    stock: "",
    categoria: "",
  });

  const [productoEliminar, setProductoEliminar] = useState(null);
  const navigate = useNavigate(); // Hook para redirigir

  // URL del backend
  const API_URL = "http://20.185.83.63:8005/api/productos";

  useEffect(() => {
    obtenerProductos();
  }, []);

  const obtenerProductos = async () => {
    try {
      const response = await axios.get(API_URL);
      setProductos(response.data);
    } catch (error) {
      console.error("Error al obtener productos:", error);
    }
  };

  const abrirModal = (producto = null) => {
    if (producto) {
      setProductoActual({ ...producto });
    } else {
      setProductoActual({
        id: null,
        nombre: "",
        descripcion: "",
        precio: "",
        stock: "",
        categoria: "",
        unidadMedida: "",
      });
    }
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
  };

  const cerrarErrorModal = () => {
    setShowErrorModal(false);
    setErrorMessages([]);
  };

  const guardarProducto = async () => {
    try {
      if (productoActual.id) {
        await axios.put(`${API_URL}/${productoActual.id}`, productoActual);
      } else {
        await axios.post(API_URL, productoActual);
      }
      obtenerProductos();
      cerrarModal();
    } catch (error) {
      if (error.response && error.response.status === 400) {
        // Capturar errores de validación
        const errores = Object.values(error.response.data);
        setErrorMessages(errores);
        setShowErrorModal(true);
      } else {
        console.error("Error al guardar producto:", error);
      }
    }
  };

  const abrirDeleteModal = (producto) => {
    setProductoEliminar(producto);
    setShowDeleteModal(true);
  };

  const cerrarDeleteModal = () => {
    setShowDeleteModal(false);
    setProductoEliminar(null);
  };

  const eliminarProducto = async () => {
    try {
      if (productoEliminar) {
        await axios.delete(`${API_URL}/${productoEliminar.id}`);
        obtenerProductos();
        cerrarDeleteModal();
      }
    } catch (error) {
      console.error("Error al eliminar producto:", error);
      alert("No se pudo eliminar el producto.");
    }
  };

  return (
    <>
      <AppNavbar /> {/* Agregamos la barra de navegación */}
      <Container className="mt-5">
        <div className="d-flex justify-content-between align-items-center mb-4">
        <Button style={{ backgroundColor: "#4CAF50", borderColor: "#4CAF50", color: "white" }} onClick={() => navigate("/")}>
        <FaArrowLeft /> Atrás
          </Button>
          <h2 className="text-center flex-grow-1 product-title">Gestión de Productos</h2>
          </div>

        <Button variant="success" onClick={() => abrirModal()} className="mb-3">
          <FaPlus /> Agregar Producto
        </Button>

        <Table striped bordered hover responsive>
          <thead>
            <tr className="text-center">
              <th>ID</th>
              <th>Nombre</th>
              <th>Descripción</th>
              <th>Unidad</th>
              <th>Precio c/u</th>
              <th>Stock</th>
              <th>Categoría</th>
              <th>Fecha de Recepcion</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {productos.map((producto) => (
              <tr key={producto.id}>
                <td className="text-center">{producto.id}</td>
                <td>{producto.nombre}</td>
                <td>{producto.descripcion}</td>
                <td className="text-center">{producto.unidadMedida}</td>
                <td className="text-center">${producto.precio}</td>
                <td className="text-center">{producto.stock}</td>
                <td className="text-center">{producto.categoria}</td>
                <td className="text-center">{new Date(producto.creadoEl).toLocaleString("es-ES", { day: "2-digit", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" })}</td>
                <td className="text-center">

                  <Button variant="warning" size="sm" onClick={() => abrirModal(producto)} className="me-2">
                    <FaEdit />
                  </Button>
                  <Button variant="danger" size="sm" onClick={() => abrirDeleteModal(producto)}>
                    <FaTrash />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>

        {/* Modal para agregar/editar producto */}
        <Modal show={showModal} onHide={cerrarModal}>
          <Modal.Header closeButton>
            <Modal.Title>{productoActual.id ? "Editar Producto" : "Agregar Producto"}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>Nombre</Form.Label>
                <Form.Control
                  type="text"
                  value={productoActual.nombre}
                  onChange={(e) => setProductoActual({ ...productoActual, nombre: e.target.value })}
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Descripción</Form.Label>
                <Form.Control
                  as="textarea"
                  value={productoActual.descripcion}
                  onChange={(e) => setProductoActual({ ...productoActual, descripcion: e.target.value })}
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Unidad de Medida</Form.Label>
                <Form.Control
                  as="select"
                  value={productoActual.unidadMedida}
                  onChange={(e) => setProductoActual({ ...productoActual, unidadMedida: e.target.value })}
                >
                  <option value="">Seleccione una medida</option>
                  <option value="Unidad">Unidad</option>
                  <option value="Libra">Libra</option>
                  <option value="Kilo">Kilo</option>
                  <option value="Gramo">Gramo</option>
                  <option value="Litro">Litro</option>
                  <option value="Mililitro">Mililitro</option>
                  <option value="Bolsa">Bolsa</option>
                  <option value="Caja">Caja</option>
                  <option value="Botella">Botella</option>
                  <option value="Otro">Otro</option>
                </Form.Control>
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Precio $</Form.Label>
                <Form.Control
                  type="number"
                  value={productoActual.precio}
                  onChange={(e) => setProductoActual({ ...productoActual, precio: e.target.value })}
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Stock</Form.Label>
                <Form.Control
                  type="number"
                  value={productoActual.stock}
                  onChange={(e) => setProductoActual({ ...productoActual, stock: e.target.value })}
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Categoría</Form.Label>
                <Form.Control
                  as="select"
                  value={productoActual.categoria}
                  onChange={(e) => setProductoActual({ ...productoActual, categoria: e.target.value })}
                  >
                  <option value="">Seleccione una categoria</option>
                  <option value="Frutas">Frutas</option>
                  <option value="Verduras">Verduras</option>
                  <option value="Legumbres">Legumbres</option>
                  <option value="Hortalizas">Hortalizas</option>
                  <option value="Tubérculos">Tubérculos</option>
                  <option value="Hierbas Aromáticas">Hierbas Aromáticas</option>
                  <option value="Granos">Granos</option>
                  <option value="Frutos Secos">Frutos Secos</option>
                  <option value="Especias">Especias</option>
                  <option value="Otros">Otros</option>
                </Form.Control>
              </Form.Group>
            </Form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={cerrarModal}>
              Cancelar
            </Button>
            <Button variant="primary" onClick={guardarProducto}>
              Guardar
            </Button>
          </Modal.Footer>
        </Modal>

        {/* Modal para mostrar errores de validación */}
        <Modal show={showErrorModal} onHide={cerrarErrorModal}>
          <Modal.Header closeButton>
            <Modal.Title>Error en la validación</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {errorMessages.map((error, index) => (
              <Alert key={index} variant="danger">
                {error}
              </Alert>
            ))}
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={cerrarErrorModal}>
              Cerrar
            </Button>
          </Modal.Footer>
        </Modal>

        {/* Modal para eliminar producto */}
        <Modal show={showDeleteModal} onHide={cerrarDeleteModal}>
          <Modal.Header closeButton>
            <Modal.Title>Eliminar Producto</Modal.Title>
          </Modal.Header>
          <Modal.Body>¿Estás seguro de que deseas eliminar el producto <strong>{productoEliminar?.nombre}</strong>?</Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={cerrarDeleteModal}>
              Cancelar
            </Button>
            <Button variant="danger" onClick={eliminarProducto}>
              Eliminar
            </Button>
          </Modal.Footer>
        </Modal>
      </Container>
      <Footer/>
    </>
  );
};

export default Productos;