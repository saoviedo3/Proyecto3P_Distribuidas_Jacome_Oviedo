import React, { useState, useEffect } from "react";
import { Container, Form, Button, Alert } from "react-bootstrap";
import Select from "react-select";
import axios from "axios";
import { useNavigate } from "react-router-dom"; 
import { FaArrowLeft } from "react-icons/fa"; 
import AppNavbar from "../components/Navbar";
import Footer from "../components/Footer";

const Ventas = () => {
  const [productos, setProductos] = useState([]);
  const [productoSeleccionado, setProductoSeleccionado] = useState(null);
  const [cantidad, setCantidad] = useState("");
  const [totalVenta, setTotalVenta] = useState(0); 
  const [mensaje, setMensaje] = useState(null);
  const [error, setError] = useState(null);

  const API_URL = "http://20.185.83.63:8005/api";
  const navigate = useNavigate(); 

  useEffect(() => {
    obtenerProductos();
  }, []);

  useEffect(() => {
    calcularTotal(); 
  }, [productoSeleccionado, cantidad]);

  const obtenerProductos = async () => {
    try {
      const response = await axios.get(`${API_URL}/productos`);
      setProductos(response.data);
    } catch (error) {
      console.error("Error al obtener productos:", error);
    }
  };

  const calcularTotal = () => {
    if (productoSeleccionado && cantidad > 0) {
      const precioUnitario = productoSeleccionado.precio || 0;
      setTotalVenta(precioUnitario * cantidad);
    } else {
      setTotalVenta(0);
    }
  };

  const handleVenta = async () => {
    setMensaje(null);
    setError(null);

    if (!productoSeleccionado || !cantidad) {
      setError("Por favor, selecciona un producto y la cantidad.");
      return;
    }

    try {
      const response = await axios.post(`${API_URL}/ventas/${productoSeleccionado.value}/${cantidad}`);
      setMensaje(response.data.message);
      setCantidad("");
      setProductoSeleccionado(null);
      setTotalVenta(0); // Reiniciar el total de la venta
      obtenerProductos();
    } catch (error) {
      setError(error.response?.data?.message || "Error al registrar la venta.");
    }
  };

  return (
    <>
      <AppNavbar />
      <Container className="my-4">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <Button variant="secondary" onClick={() => navigate("/")}>
            <FaArrowLeft /> Atrás
          </Button>
          <h1 className="text-center flex-grow-1 product-title">Registrar Venta</h1>
        </div>
        <br />
        <Form>
          <Form.Group>
            <h3 className="text-center">Selecciona un producto para vender</h3>
            <Select
              options={productos.map((producto) => ({
                value: producto.id,
                label: `${producto.nombre} - Stock: ${producto.stock} ${producto.unidadMedida}(s) - Precio: $${producto.precio} C/${producto.unidadMedida}`,
                precio: producto.precio 
              }))}
              value={productoSeleccionado}
              onChange={setProductoSeleccionado}
              placeholder="Busca o selecciona un producto..."
              isSearchable
            />
          </Form.Group>
          <br />
          <Form.Group>
            <h3 className="text-center">Ingrese una cantidad</h3>
            <Form.Control
              type="number"
              value={cantidad}
              onChange={(e) => setCantidad(e.target.value)}
              placeholder="Ingrese la cantidad a vender"
            />
          </Form.Group>

          
          {totalVenta > 0 && (
            <h3 className="text-center mt-3">
              <strong>Total: ${totalVenta.toFixed(2)}</strong>
            </h3>
          )}

          <Button variant="success" className="mt-3 d-block mx-auto" style={{ backgroundColor: "#4CAF50", borderColor: "#4CAF50", color: "white" }} onClick={handleVenta}>
            Registrar Venta
          </Button>
        </Form>

        {mensaje && <Alert variant="success" className="mt-3">{mensaje}</Alert>}
        {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
      </Container>
      <Footer />
    </>
  );
};

export default Ventas;
