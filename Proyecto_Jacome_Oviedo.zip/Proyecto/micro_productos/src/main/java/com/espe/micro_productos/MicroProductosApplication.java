package com.espe.micro_productos;  // Asegúrate de que el paquete coincida exactamente con la estructura de carpetas

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroProductosApplication {
	public static void main(String[] args) {
		SpringApplication.run(MicroProductosApplication.class, args);
	}
}
