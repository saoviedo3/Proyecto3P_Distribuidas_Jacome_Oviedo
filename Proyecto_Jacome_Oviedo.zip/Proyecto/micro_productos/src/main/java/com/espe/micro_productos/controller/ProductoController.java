package com.espe.micro_productos.controller;

import com.espe.micro_productos.models.entities.Producto;
import com.espe.micro_productos.services.ProductoService;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/productos")
public class ProductoController {

    @Autowired
    private ProductoService service;

    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody Producto producto, BindingResult result) {
        if (result.hasErrors()) {
            Map<String, String> errors = new HashMap<>();
            result.getFieldErrors().forEach(err -> errors.put(err.getField(), err.getDefaultMessage()));
            return ResponseEntity.badRequest().body(errors);
        }
        Producto productoDb = service.save(producto);
        return ResponseEntity.status(HttpStatus.CREATED).body(productoDb);
    }

    @GetMapping
    public ResponseEntity<List<Producto>> listAll() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        Optional<Producto> productoOptional = service.findById(id);
        if (productoOptional.isPresent()) {
            return ResponseEntity.ok(productoOptional.get());
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonMap("message", "Producto no encontrado"));
    }

    @GetMapping("/perfil")
    public String getPerfil(@RequestHeader("Authorization") String token) {
        try {
            String CLIENT_ID = "429908816051-80j1hf60q4t94tu5ikq0rbgtpleeanc4.apps.googleusercontent.com";

            GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(
                    new NetHttpTransport(), 
                    new GsonFactory()
            )
            .setAudience(Collections.singletonList(CLIENT_ID))
            .build();

            GoogleIdToken idToken = verifier.verify(token.replace("Bearer ", ""));
            if (idToken != null) {
                GoogleIdToken.Payload payload = idToken.getPayload();
                return "Usuario autenticado: " + payload.getEmail();
            } else {
                return "Token inválido";
            }

        } catch (GeneralSecurityException | IOException e) {
            return "Error verificando el token";
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@Valid @RequestBody Producto producto, BindingResult result, @PathVariable Long id) {
        if (result.hasErrors()) {
            Map<String, String> errors = new HashMap<>();
            result.getFieldErrors().forEach(err -> errors.put(err.getField(), err.getDefaultMessage()));
            return ResponseEntity.badRequest().body(errors);
        }
        Optional<Producto> productoOptional = service.findById(id);
        if (productoOptional.isPresent()) {
            Producto productoDb = productoOptional.get();
            productoDb.setNombre(producto.getNombre());
            productoDb.setDescripcion(producto.getDescripcion());
            productoDb.setPrecio(producto.getPrecio());
            productoDb.setStock(producto.getStock());
            productoDb.setCategoria(producto.getCategoria());
            productoDb.setUnidadMedida(producto.getUnidadMedida()); // Se agrega la unidad de medida
            return ResponseEntity.status(HttpStatus.CREATED).body(service.save(productoDb));
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonMap("message", "Producto no encontrado"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        Optional<Producto> producto = service.findById(id);
        if (producto.isPresent()) {
            service.delete(id);
            return ResponseEntity.ok(Collections.singletonMap("message", "Producto eliminado correctamente"));
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonMap("message", "Producto no encontrado"));
    }

    @GetMapping("/unidad-medida/{unidadMedida}")
    public ResponseEntity<List<Producto>> getByUnidadMedida(@PathVariable String unidadMedida) {
        List<Producto> productos = service.findByUnidadMedida(unidadMedida);
        if (productos.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.emptyList());
        }
        return ResponseEntity.ok(productos);
    }
}
