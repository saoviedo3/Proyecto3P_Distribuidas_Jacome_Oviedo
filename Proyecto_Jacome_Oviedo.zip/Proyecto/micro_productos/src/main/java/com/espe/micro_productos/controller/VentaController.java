package com.espe.micro_productos.controller;

import com.espe.micro_productos.models.entities.Producto;
import com.espe.micro_productos.services.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.Optional;

@RestController
@RequestMapping("/api/ventas")
public class VentaController {

    @Autowired
    private ProductoService productoService;

    @PostMapping("/{idProducto}/{cantidad}")
    public ResponseEntity<?> registrarVenta(@PathVariable Long idProducto, @PathVariable Integer cantidad) {
        Optional<Producto> productoOptional = productoService.findById(idProducto);
        
        if (productoOptional.isPresent()) {
            Producto producto = productoOptional.get();

            if (producto.getStock() < cantidad) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Collections.singletonMap("message", "Stock insuficiente para realizar la venta"));
            }

            // Restar la cantidad vendida del stock
            producto.setStock(producto.getStock() - cantidad);
            productoService.save(producto);

            // Verificar si el stock es menor a 5 y generar alerta
            if (producto.getStock() < 5) {
                return ResponseEntity.ok(Collections.singletonMap("message", "Venta registrada. ¡Alerta! Stock bajo: " + producto.getStock()));
            }

            return ResponseEntity.ok(Collections.singletonMap("message", "Venta registrada correctamente"));
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonMap("message", "Producto no encontrado"));
    }
}
