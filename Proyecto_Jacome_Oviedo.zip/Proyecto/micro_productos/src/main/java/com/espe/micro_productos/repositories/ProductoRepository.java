package com.espe.micro_productos.repositories;

import com.espe.micro_productos.models.entities.Producto;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ProductoRepository extends CrudRepository<Producto, Long> {
    // Buscar productos por categoría
    List<Producto> findByCategoria(String categoria);

    // Buscar productos con stock menor a un valor determinado
    List<Producto> findByStockLessThan(Integer stock);

    // Buscar productos por nombre (ignorando mayúsculas/minúsculas)
    List<Producto> findByNombreContainingIgnoreCase(String nombre);

    // Buscar productos por unidad de medida
    List<Producto> findByUnidadMedida(String unidadMedida);
}
