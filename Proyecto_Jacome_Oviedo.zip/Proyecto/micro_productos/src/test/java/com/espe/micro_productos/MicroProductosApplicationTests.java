package com.espe.micro_productos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
